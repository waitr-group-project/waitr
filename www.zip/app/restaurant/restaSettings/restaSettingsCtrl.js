(function () {
  angular
    .module('waitrApp')
    .controller('restaSettingsCtrl', [restaSettingsCtrl]);

  function restaSettingsCtrl () {
    var rsc = this;

  

  }

})();