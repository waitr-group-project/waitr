(function () {
  angular
    .module('waitrApp')
    .controller('restaRestaurantCtrl', [restaAdminCtrl]);

  function restaAdminCtrl () {
    var rrc = this;








    

  }

})();
