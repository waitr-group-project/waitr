(function () {
  angular
    .module('waitrApp')
    .controller('custCustomerCtrl', [custCustomerCtrl]);

  function custCustomerCtrl () {
    var ccc = this;

  

  }

})();
